// CryptoDesk Large Card - ES5 Compatible for iOS 9.3.5
(function() {
    var currentCoin = localStorage.getItem('cryptodesk_coin') || 'BTC';
    var chartPoints = [89000, 89400, 88800, 90200, 90800, 90100, 91500, 91200, 91800, 91091];
    var isPositive = true;

    var coinIcons = {
        'BTC': '₿', 'ETH': 'Ξ', 'SOL': '◎', 'DOGE': 'Ð',
        'XRP': '✕', 'BNB': '🟡', 'ADA': '₳', 'PEPE': '🐸'
    };

    function drawChart() {
        var canvas = document.getElementById('crypto-large-chart');
        if (!canvas) return;
        var ctx = canvas.getContext('2d');
        if (!ctx) return;

        var dpr = window.devicePixelRatio || 1;
        var rect = canvas.getBoundingClientRect();
        var width = rect.width || 248;
        var height = rect.height || 110;

        canvas.width = width * dpr;
        canvas.height = height * dpr;
        ctx.scale(dpr, dpr);

        var minVal = chartPoints[0];
        var maxVal = chartPoints[0];
        for (var k = 1; k < chartPoints.length; k++) {
            if (chartPoints[k] < minVal) minVal = chartPoints[k];
            if (chartPoints[k] > maxVal) maxVal = chartPoints[k];
        }
        if (minVal === maxVal) { maxVal += 1; minVal -= 1; }

        var stepX = width / (chartPoints.length - 1);
        function getY(val) {
            return height - ((val - minVal) / (maxVal - minVal)) * (height - 18) - 9;
        }

        var lineColor = isPositive ? '#34c759' : '#ff3b30';
        var gradStart = isPositive ? 'rgba(52, 199, 89, 0.45)' : 'rgba(255, 59, 48, 0.45)';
        var gradEnd = isPositive ? 'rgba(52, 199, 89, 0.0)' : 'rgba(255, 59, 48, 0.0)';

        // Fill area
        var grad = ctx.createLinearGradient(0, 0, 0, height);
        grad.addColorStop(0, gradStart);
        grad.addColorStop(1, gradEnd);

        ctx.beginPath();
        ctx.moveTo(0, getY(chartPoints[0]));
        for (var i = 1; i < chartPoints.length; i++) {
            var px = (i - 1) * stepX;
            var py = getY(chartPoints[i - 1]);
            var cx = i * stepX;
            var cy = getY(chartPoints[i]);
            var mx = (px + cx) / 2;
            ctx.quadraticCurveTo(px, py, mx, (py + cy) / 2);
        }
        ctx.lineTo(width, getY(chartPoints[chartPoints.length - 1]));
        ctx.lineTo(width, height);
        ctx.lineTo(0, height);
        ctx.closePath();
        ctx.fillStyle = grad;
        ctx.fill();

        // Stroke line
        ctx.beginPath();
        ctx.moveTo(0, getY(chartPoints[0]));
        for (var j = 1; j < chartPoints.length; j++) {
            var pxx = (j - 1) * stepX;
            var pyy = getY(chartPoints[j - 1]);
            var cxx = j * stepX;
            var cyy = getY(chartPoints[j]);
            var mxx = (pxx + cxx) / 2;
            ctx.quadraticCurveTo(pxx, pyy, mxx, (pyy + cyy) / 2);
        }
        ctx.lineTo(width, getY(chartPoints[chartPoints.length - 1]));
        ctx.strokeStyle = lineColor;
        ctx.lineWidth = 2.4;
        ctx.stroke();
    }

    function fetchCoinData() {
        var symbol = currentCoin.toUpperCase().trim();
        var pair = symbol + 'USDT';

        var titleEl = document.getElementById('coin-title');
        var iconEl = document.getElementById('coin-icon');
        if (titleEl) titleEl.textContent = symbol + ' / USDT';
        if (iconEl) iconEl.textContent = coinIcons[symbol] || '🪙';

        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'https://api.binance.com/api/v3/ticker/24hr?symbol=' + pair, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                try {
                    var data = JSON.parse(xhr.responseText);
                    var price = parseFloat(data.lastPrice);
                    var change = parseFloat(data.priceChangePercent);
                    var high = parseFloat(data.highPrice);
                    var low = parseFloat(data.lowPrice);
                    var vol = parseFloat(data.volume);

                    var pEl = document.getElementById('coin-price');
                    var cEl = document.getElementById('coin-change');
                    var hEl = document.getElementById('stat-high');
                    var lEl = document.getElementById('stat-low');
                    var vEl = document.getElementById('stat-vol');

                    var decimals = price >= 1 ? 2 : (price >= 0.001 ? 4 : 6);
                    if (pEl) pEl.textContent = '$' + price.toLocaleString('en-US', {minimumFractionDigits: decimals, maximumFractionDigits: decimals});
                    if (hEl) hEl.textContent = '$' + high.toLocaleString('en-US', {minimumFractionDigits: decimals, maximumFractionDigits: decimals});
                    if (lEl) lEl.textContent = '$' + low.toLocaleString('en-US', {minimumFractionDigits: decimals, maximumFractionDigits: decimals});
                    if (vEl) {
                        var volStr = vol >= 1000000 ? (vol/1000000).toFixed(1) + 'M' : (vol >= 1000 ? (vol/1000).toFixed(1) + 'K' : vol.toFixed(0));
                        vEl.textContent = volStr + ' ' + symbol;
                    }

                    if (cEl) {
                        isPositive = change >= 0;
                        cEl.textContent = (isPositive ? '+' : '') + change.toFixed(2) + '%';
                        cEl.className = 'change-pill' + (isPositive ? '' : ' down');
                    }

                    chartPoints.push(price);
                    if (chartPoints.length > 25) chartPoints.shift();
                    drawChart();
                } catch(e) {}
            }
        };
        xhr.send();
    }

    function fetchFearGreed() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'https://api.alternative.me/fng/?limit=1', true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                try {
                    var res = JSON.parse(xhr.responseText);
                    var item = res.data[0];
                    var badge = document.getElementById('fg-badge');
                    if (badge) badge.textContent = item.value + ' ' + item.value_classification;
                } catch(e) {}
            }
        };
        xhr.send();
    }

    function setupModal() {
        var modal = document.getElementById('modal-settings');
        var btnOpen = document.getElementById('btn-open-settings');
        var btnHeader = document.getElementById('btn-coin-header');
        var btnClose = document.getElementById('btn-close-modal');
        var btnCancel = document.getElementById('btn-cancel');
        var btnSave = document.getElementById('btn-save');
        var inputCoin = document.getElementById('input-coin');
        var chips = document.querySelectorAll('.chip');

        function openModal() {
            if (inputCoin) inputCoin.value = currentCoin;
            if (modal) modal.className = 'modal-overlay active';
        }
        function closeModal() {
            if (modal) modal.className = 'modal-overlay';
        }

        if (btnOpen) btnOpen.onclick = openModal;
        if (btnHeader) btnHeader.onclick = openModal;
        if (btnClose) btnClose.onclick = closeModal;
        if (btnCancel) btnCancel.onclick = closeModal;

        for (var i = 0; i < chips.length; i++) {
            chips[i].onclick = function() {
                var c = this.getAttribute('data-coin');
                if (inputCoin) inputCoin.value = c;
            };
        }

        if (btnSave) {
            btnSave.onclick = function() {
                var val = (inputCoin.value || '').toUpperCase().trim();
                if (val) {
                    currentCoin = val;
                    localStorage.setItem('cryptodesk_coin', currentCoin);
                    fetchCoinData();
                }
                closeModal();
            };
        }
    }

    window.addEventListener('load', function() {
        drawChart();
        fetchCoinData();
        fetchFearGreed();
        setupModal();
        setInterval(fetchCoinData, 15000);
    });

    window.addEventListener('resize', drawChart);
})();
