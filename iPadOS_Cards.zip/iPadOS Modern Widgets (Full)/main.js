// iPadOS Modern Widgets - ES5 Compatible for iOS 9.3.5 WebKit
(function() {
    // 1. Draw Stock Chart
    function drawStockChart() {
        var canvas = document.getElementById('stock-chart');
        if (!canvas) return;
        var ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Retina display scaling
        var dpr = window.devicePixelRatio || 1;
        var rect = canvas.getBoundingClientRect();
        var width = rect.width || 280;
        var height = rect.height || 105;

        canvas.width = width * dpr;
        canvas.height = height * dpr;
        ctx.scale(dpr, dpr);

        // Chart Data (AAPL upward wave like screenshot)
        var points = [
            18, 22, 19, 25, 30, 24, 20, 16, 22, 28, 
            35, 32, 40, 48, 45, 52, 60, 58, 65, 72, 
            68, 75, 82, 78, 85, 90, 84, 88, 92, 95
        ];

        var stepX = width / (points.length - 1);
        var minY = 10;
        var maxY = 100;

        function getY(val) {
            // Invert Y axis for canvas
            return height - ((val - minY) / (maxY - minY)) * (height - 20) - 10;
        }

        // Draw Area Fill Gradient
        var gradient = ctx.createLinearGradient(0, 0, 0, height);
        gradient.addColorStop(0, 'rgba(52, 199, 89, 0.45)');
        gradient.addColorStop(0.7, 'rgba(52, 199, 89, 0.1)');
        gradient.addColorStop(1, 'rgba(52, 199, 89, 0.0)');

        ctx.beginPath();
        ctx.moveTo(0, getY(points[0]));
        for (var i = 1; i < points.length; i++) {
            var prevX = (i - 1) * stepX;
            var prevY = getY(points[i - 1]);
            var currX = i * stepX;
            var currY = getY(points[i]);
            var midX = (prevX + currX) / 2;
            ctx.quadraticCurveTo(prevX, prevY, midX, (prevY + currY) / 2);
        }
        ctx.lineTo(width, getY(points[points.length - 1]));
        ctx.lineTo(width, height);
        ctx.lineTo(0, height);
        ctx.closePath();
        ctx.fillStyle = gradient;
        ctx.fill();

        // Draw Line
        ctx.beginPath();
        ctx.moveTo(0, getY(points[0]));
        for (var j = 1; j < points.length; j++) {
            var pX = (j - 1) * stepX;
            var pY = getY(points[j - 1]);
            var cX = j * stepX;
            var cY = getY(points[j]);
            var mX = (pX + cX) / 2;
            ctx.quadraticCurveTo(pX, pY, mX, (pY + cY) / 2);
        }
        ctx.lineTo(width, getY(points[points.length - 1]));
        ctx.strokeStyle = '#34c759';
        ctx.lineWidth = 2.2;
        ctx.stroke();
    }

    // 2. Battery Monitoring (if supported by browser/iOS)
    function initBattery() {
        if (navigator.getBattery) {
            navigator.getBattery().then(function(battery) {
                function updateBatteryUI() {
                    var level = Math.round(battery.level * 100);
                    var pctEl = document.getElementById('pct-ipad');
                    var ringEl = document.getElementById('ring-ipad');
                    if (pctEl) pctEl.textContent = level + '%';
                    if (ringEl) {
                        var circum = 2 * Math.PI * 18; // r = 18 -> ~113.1
                        var offset = circum - (circum * level / 100);
                        ringEl.style.strokeDashoffset = offset;
                    }
                }
                updateBatteryUI();
                battery.addEventListener('levelchange', updateBatteryUI);
            }).catch(function(e) {});
        }
    }

    // Init on load & resize
    window.addEventListener('load', function() {
        drawStockChart();
        initBattery();
    });

    window.addEventListener('resize', function() {
        drawStockChart();
    });
})();
