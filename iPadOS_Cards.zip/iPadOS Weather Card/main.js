// Weather Card Widget - Live Open-Meteo Weather & Location Settings
(function() {
    var savedCity = localStorage.getItem('weather_city') || 'UC San Diego';
    var savedLat = localStorage.getItem('weather_lat') || '32.8801';
    var savedLon = localStorage.getItem('weather_lon') || '-117.2340';
    var savedUnit = localStorage.getItem('weather_unit') || 'F'; // 'F' or 'C'

    function codeToInfo(code) {
        if (code === 0) return { icon: '☀️', text: 'Clear' };
        if (code === 1) return { icon: '🌤️', text: 'Mostly Sunny' };
        if (code === 2) return { icon: '⛅', text: 'Partly Cloudy' };
        if (code === 3) return { icon: '☁️', text: 'Overcast' };
        if (code === 45 || code === 48) return { icon: '🌫️', text: 'Fog' };
        if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return { icon: '🌧️', text: 'Rain' };
        if ((code >= 71 && code <= 77) || (code >= 85 && code <= 86)) return { icon: '❄️', text: 'Snow' };
        if (code >= 95) return { icon: '⛈️', text: 'Storm' };
        return { icon: '⛅', text: 'Cloudy' };
    }

    function formatTemp(celsius) {
        if (savedUnit === 'F') {
            return Math.round((celsius * 9 / 5) + 32) + '°';
        }
        return Math.round(celsius) + '°';
    }

    function fetchWeather() {
        var cityEl = document.getElementById('weather-city');
        if (cityEl) cityEl.textContent = savedCity;

        var url = 'https://api.open-meteo.com/v1/forecast?latitude=' + savedLat + '&longitude=' + savedLon +
                  '&current_weather=true&hourly=temperature_2m,weathercode&daily=weathercode,temperature_2m_max,temperature_2m_min&timezone=auto';

        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                try {
                    var data = JSON.parse(xhr.responseText);
                    var cw = data.current_weather;
                    var cInfo = codeToInfo(cw.weathercode);

                    var tempEl = document.getElementById('weather-temp');
                    var iconEl = document.getElementById('cond-icon');
                    var textEl = document.getElementById('cond-text');
                    var hiloEl = document.getElementById('cond-hi-lo');

                    if (tempEl) tempEl.textContent = formatTemp(cw.temperature);
                    if (iconEl) iconEl.textContent = cInfo.icon;
                    if (textEl) textEl.textContent = cInfo.text;

                    var daily = data.daily;
                    if (daily && daily.temperature_2m_max && hiloEl) {
                        var hi = formatTemp(daily.temperature_2m_max[0]);
                        var lo = formatTemp(daily.temperature_2m_min[0]);
                        hiloEl.textContent = 'H:' + hi + ' L:' + lo;
                    }

                    // Render hourly forecast
                    var hourly = data.hourly;
                    var stripEl = document.getElementById('hourly-strip');
                    if (hourly && hourly.temperature_2m && stripEl) {
                        var nowH = new Date().getHours();
                        var html = '';
                        for (var i = 0; i < 5; i++) {
                            var hIdx = (nowH + i * 2) % hourly.temperature_2m.length;
                            var t = formatTemp(hourly.temperature_2m[hIdx]);
                            var code = hourly.weathercode ? hourly.weathercode[hIdx] : 0;
                            var info = codeToInfo(code);
                            var timeLabel = i === 0 ? 'Now' : ((nowH + i * 2) % 24) + ':00';
                            html += '<div class="hour-col"><span class="hour-time">' + timeLabel + '</span><span class="hour-icon">' + info.icon + '</span><span class="hour-temp">' + t + '</span></div>';
                        }
                        stripEl.innerHTML = html;
                    }

                    // Render 3-day forecast
                    var dayStrip = document.getElementById('daily-strip');
                    if (daily && dayStrip) {
                        var dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                        var todayIdx = new Date().getDay();
                        var dHtml = '';
                        for (var d = 0; d < 3; d++) {
                            var dName = d === 0 ? 'Today' : dayNames[(todayIdx + d) % 7];
                            var dCode = daily.weathercode ? daily.weathercode[d] : 0;
                            var dInfo = codeToInfo(dCode);
                            var maxT = formatTemp(daily.temperature_2m_max[d]);
                            dHtml += '<div class="day-row"><span class="day-name">' + dName + '</span><span class="day-icon">' + dInfo.icon + '</span><div class="bar-track"><div class="bar-fill" style="left:20%;width:55%;"></div></div><span class="day-temps">' + maxT + '</span></div>';
                        }
                        dayStrip.innerHTML = dHtml;
                    }
                } catch(e) {}
            }
        };
        xhr.send();
    }

    function searchCityAndSave(cityName, onDone) {
        var geoUrl = 'https://geocoding-api.open-meteo.com/v1/search?name=' + encodeURIComponent(cityName) + '&count=1&language=en&format=json';
        var xhr = new XMLHttpRequest();
        xhr.open('GET', geoUrl, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    try {
                        var res = JSON.parse(xhr.responseText);
                        if (res.results && res.results.length > 0) {
                            var item = res.results[0];
                            savedCity = item.name + (item.country_code ? ' (' + item.country_code.toUpperCase() + ')' : '');
                            savedLat = item.latitude;
                            savedLon = item.longitude;
                            localStorage.setItem('weather_city', savedCity);
                            localStorage.setItem('weather_lat', savedLat);
                            localStorage.setItem('weather_lon', savedLon);
                            fetchWeather();
                            if (onDone) onDone();
                            return;
                        }
                    } catch(e) {}
                }
                // Fallback: just save the typed name
                savedCity = cityName;
                localStorage.setItem('weather_city', savedCity);
                if (onDone) onDone();
            }
        };
        xhr.send();
    }

    function setupModal() {
        var modal = document.getElementById('weather-modal');
        var btnOpen = document.getElementById('btn-weather-gear');
        var cityTap = document.getElementById('city-tap');
        var btnClose = document.getElementById('btn-close-wmodal');
        var btnCancel = document.getElementById('btn-wcancel');
        var btnSave = document.getElementById('btn-wsave');
        var inputCity = document.getElementById('input-city');
        var unitC = document.getElementById('unit-c');
        var unitF = document.getElementById('unit-f');

        function openModal() {
            if (inputCity) inputCity.value = savedCity;
            if (unitC && unitF) {
                unitC.className = 'btn-unit' + (savedUnit === 'C' ? ' active' : '');
                unitF.className = 'btn-unit' + (savedUnit === 'F' ? ' active' : '');
            }
            if (modal) modal.className = 'weather-modal active';
        }
        function closeModal() {
            if (modal) modal.className = 'weather-modal';
        }

        if (btnOpen) btnOpen.onclick = openModal;
        if (cityTap) cityTap.onclick = openModal;
        if (btnClose) btnClose.onclick = closeModal;
        if (btnCancel) btnCancel.onclick = closeModal;

        if (unitC) unitC.onclick = function() {
            savedUnit = 'C';
            unitC.className = 'btn-unit active';
            if (unitF) unitF.className = 'btn-unit';
        };
        if (unitF) unitF.onclick = function() {
            savedUnit = 'F';
            unitF.className = 'btn-unit active';
            if (unitC) unitC.className = 'btn-unit';
        };

        if (btnSave) {
            btnSave.onclick = function() {
                localStorage.setItem('weather_unit', savedUnit);
                var typed = (inputCity.value || '').trim();
                if (typed) {
                    searchCityAndSave(typed, closeModal);
                } else {
                    fetchWeather();
                    closeModal();
                }
            };
        }
    }

    window.addEventListener('load', function() {
        fetchWeather();
        setupModal();
        setInterval(fetchWeather, 60000); // Check weather every 1 min
    });
})();
