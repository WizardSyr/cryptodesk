// Binance Live Trades & PnL Widget (100% Read-Only Safety, iOS 9 ES5 Compatible)
(function() {
    var apiKey = localStorage.getItem('binance_user_apikey') || '';
    var secretKey = localStorage.getItem('binance_user_secret') || '';
    var activeTab = localStorage.getItem('binance_active_tab') || 'futures'; // 'futures' or 'spot'
    var timeOffset = 0;

    var elTotalPnl = document.getElementById('total-pnl');
    var elWalletBal = document.getElementById('wallet-bal');
    var elTradesList = document.getElementById('trades-list');
    var tabFutures = document.getElementById('tab-futures');
    var tabSpot = document.getElementById('tab-spot');

    var modal = document.getElementById('modal-settings');
    var btnGear = document.getElementById('btn-open-settings');
    var btnClose = document.getElementById('btn-close-modal');
    var btnCancel = document.getElementById('btn-cancel-modal');
    var btnSave = document.getElementById('btn-save-keys');
    var btnClear = document.getElementById('btn-clear-keys');
    var inputKey = document.getElementById('input-api-key');
    var inputSecret = document.getElementById('input-secret-key');

    function syncTime(callback) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'https://api.binance.com/api/v3/time', true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                try {
                    var data = JSON.parse(xhr.responseText);
                    timeOffset = data.serverTime - Date.now();
                } catch(e) {}
            }
            if (xhr.readyState === 4 && callback) callback();
        };
        xhr.send();
    }

    function sign(queryStr, secret) {
        if (typeof CryptoJS !== 'undefined') {
            return CryptoJS.HmacSHA256(queryStr, secret).toString(CryptoJS.enc.Hex);
        }
        return '';
    }

    function formatNumber(num, decimals) {
        var n = parseFloat(num);
        if (isNaN(n)) return '0.00';
        return n.toLocaleString('en-US', {
            minimumFractionDigits: decimals !== undefined ? decimals : 2,
            maximumFractionDigits: decimals !== undefined ? decimals : 2
        });
    }

    function renderEmpty(title, sub, icon) {
        elTradesList.innerHTML = '<div class="empty-box">' +
            '<div class="empty-icon">' + (icon || '🔒') + '</div>' +
            '<div class="empty-text">' + title + '</div>' +
            '<div class="empty-sub">' + sub + '</div>' +
            '</div>';
    }

    function fetchFutures() {
        if (!apiKey || !secretKey) {
            renderEmpty('Connect Read-Only API', 'Tap ⚙ to enter your Binance Read-Only Key', '🔒');
            elTotalPnl.textContent = '$0.00';
            elTotalPnl.className = 'pnl-value pnl-zero';
            elWalletBal.textContent = '$0.00';
            return;
        }

        var ts = Date.now() + timeOffset;
        var query = 'recvWindow=60000&timestamp=' + ts;
        var sig = sign(query, secretKey);
        var url = 'https://fapi.binance.com/fapi/v2/positionRisk?' + query + '&signature=' + sig;

        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.setRequestHeader('X-MBX-APIKEY', apiKey);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    try {
                        var positions = JSON.parse(xhr.responseText);
                        var activePositions = [];
                        var totalPnl = 0;

                        for (var i = 0; i < positions.length; i++) {
                            var pos = positions[i];
                            var amt = parseFloat(pos.positionAmt);
                            if (amt !== 0) {
                                activePositions.push(pos);
                                totalPnl += parseFloat(pos.unRealizedProfit);
                            }
                        }

                        // Update Total PnL Header
                        var pnlSign = totalPnl > 0 ? '+' : '';
                        elTotalPnl.textContent = pnlSign + '$' + formatNumber(totalPnl, 2);
                        if (totalPnl > 0) elTotalPnl.className = 'pnl-value pnl-pos';
                        else if (totalPnl < 0) elTotalPnl.className = 'pnl-value pnl-neg';
                        else elTotalPnl.className = 'pnl-value pnl-zero';

                        if (activePositions.length === 0) {
                            renderEmpty('No Open Positions', 'All trades closed • Waiting for setup', '✅');
                            return;
                        }

                        var html = '';
                        for (var j = 0; j < activePositions.length; j++) {
                            var p = activePositions[j];
                            var isLong = parseFloat(p.positionAmt) > 0;
                            var sideText = isLong ? 'LONG ' + p.leverage + 'x' : 'SHORT ' + p.leverage + 'x';
                            var sideClass = isLong ? 'badge-side badge-long' : 'badge-side badge-short';
                            var pnl = parseFloat(p.unRealizedProfit);
                            var pnlClass = pnl >= 0 ? 'trade-pnl pnl-pos' : 'trade-pnl pnl-neg';
                            var sym = p.symbol.replace('USDT', '/USDT');

                            // Calculate approximate Return on Equity (ROE%)
                            var notional = Math.abs(parseFloat(p.positionAmt)) * parseFloat(p.entryPrice);
                            var margin = notional / (parseFloat(p.leverage) || 1);
                            var roe = margin > 0 ? (pnl / margin) * 100 : 0;
                            var roeSign = roe >= 0 ? '+' : '';

                            html += '<div class="trade-item">' +
                                '<div class="trade-top">' +
                                    '<div class="trade-sym-row">' +
                                        '<span class="trade-sym">' + sym + '</span>' +
                                        '<span class="' + sideClass + '">' + sideText + '</span>' +
                                    '</div>' +
                                    '<span class="' + pnlClass + '">' + (pnl >= 0 ? '+' : '') + '$' + formatNumber(pnl, 2) + ' (' + roeSign + formatNumber(roe, 1) + '%)</span>' +
                                '</div>' +
                                '<div class="trade-bottom">' +
                                    '<div class="trade-prices">' +
                                        '<span>Entry: ' + formatNumber(p.entryPrice) + '</span>' +
                                        '<span>Mark: ' + formatNumber(p.markPrice) + '</span>' +
                                    '</div>' +
                                    '<span class="trade-liq">Liq: ' + (parseFloat(p.liquidationPrice) > 0 ? formatNumber(p.liquidationPrice) : '--') + '</span>' +
                                '</div>' +
                            '</div>';
                        }
                        elTradesList.innerHTML = html;
                    } catch(e) {}
                } else {
                    renderEmpty('API Error (' + xhr.status + ')', 'Check Read-Only API Key in ⚙', '⚠️');
                }
            }
        };
        xhr.send();

        // Fetch Futures Balance
        var balUrl = 'https://fapi.binance.com/fapi/v2/balance?' + query + '&signature=' + sig;
        var xhrBal = new XMLHttpRequest();
        xhrBal.open('GET', balUrl, true);
        xhrBal.setRequestHeader('X-MBX-APIKEY', apiKey);
        xhrBal.onreadystatechange = function() {
            if (xhrBal.readyState === 4 && xhrBal.status === 200) {
                try {
                    var bals = JSON.parse(xhrBal.responseText);
                    for (var b = 0; b < bals.length; b++) {
                        if (bals[b].asset === 'USDT') {
                            elWalletBal.textContent = '$' + formatNumber(bals[b].balance, 2);
                            break;
                        }
                    }
                } catch(e) {}
            }
        };
        xhrBal.send();
    }

    function fetchSpot() {
        if (!apiKey || !secretKey) {
            renderEmpty('Connect Read-Only API', 'Tap ⚙ to enter your Binance Read-Only Key', '🔒');
            elTotalPnl.textContent = '$0.00';
            elTotalPnl.className = 'pnl-value pnl-zero';
            elWalletBal.textContent = '$0.00';
            return;
        }

        var ts = Date.now() + timeOffset;
        var query = 'recvWindow=60000&timestamp=' + ts;
        var sig = sign(query, secretKey);
        var url = 'https://api.binance.com/api/v3/openOrders?' + query + '&signature=' + sig;

        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.setRequestHeader('X-MBX-APIKEY', apiKey);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    try {
                        var orders = JSON.parse(xhr.responseText);
                        elTotalPnl.textContent = orders.length + ' Orders';
                        elTotalPnl.className = 'pnl-value pnl-zero';

                        if (orders.length === 0) {
                            renderEmpty('No Open Spot Orders', 'All limit orders filled', '✅');
                            return;
                        }

                        var html = '';
                        for (var i = 0; i < orders.length; i++) {
                            var o = orders[i];
                            var isBuy = o.side === 'BUY';
                            var sideClass = isBuy ? 'badge-side badge-long' : 'badge-side badge-short';
                            var sym = o.symbol.replace('USDT', '/USDT');

                            html += '<div class="trade-item">' +
                                '<div class="trade-top">' +
                                    '<div class="trade-sym-row">' +
                                        '<span class="trade-sym">' + sym + '</span>' +
                                        '<span class="' + sideClass + '">' + o.side + ' ' + o.type + '</span>' +
                                    '</div>' +
                                    '<span class="trade-pnl" style="color:#ffffff;">$' + formatNumber(o.price) + '</span>' +
                                '</div>' +
                                '<div class="trade-bottom">' +
                                    '<span>Qty: ' + formatNumber(o.origQty, 4) + '</span>' +
                                    '<span>Total: $' + formatNumber(parseFloat(o.price) * parseFloat(o.origQty), 2) + '</span>' +
                                '</div>' +
                            '</div>';
                        }
                        elTradesList.innerHTML = html;
                    } catch(e) {}
                } else {
                    renderEmpty('API Error (' + xhr.status + ')', 'Check Read-Only API Key in ⚙', '⚠️');
                }
            }
        };
        xhr.send();

        // Fetch Spot USDT Balance
        var accUrl = 'https://api.binance.com/api/v3/account?' + query + '&signature=' + sig;
        var xhrAcc = new XMLHttpRequest();
        xhrAcc.open('GET', accUrl, true);
        xhrAcc.setRequestHeader('X-MBX-APIKEY', apiKey);
        xhrAcc.onreadystatechange = function() {
            if (xhrAcc.readyState === 4 && xhrAcc.status === 200) {
                try {
                    var acc = JSON.parse(xhrAcc.responseText);
                    var balances = acc.balances;
                    for (var k = 0; k < balances.length; k++) {
                        if (balances[k].asset === 'USDT') {
                            var total = parseFloat(balances[k].free) + parseFloat(balances[k].locked);
                            elWalletBal.textContent = '$' + formatNumber(total, 2);
                            break;
                        }
                    }
                } catch(e) {}
            }
        };
        xhrAcc.send();
    }

    function refresh() {
        if (activeTab === 'futures') {
            fetchFutures();
        } else {
            fetchSpot();
        }
    }

    // Tab handlers
    tabFutures.onclick = function() {
        activeTab = 'futures';
        localStorage.setItem('binance_active_tab', activeTab);
        tabFutures.className = 'tab-btn active';
        tabSpot.className = 'tab-btn';
        refresh();
    };

    tabSpot.onclick = function() {
        activeTab = 'spot';
        localStorage.setItem('binance_active_tab', activeTab);
        tabSpot.className = 'tab-btn active';
        tabFutures.className = 'tab-btn';
        refresh();
    };

    // Modal handlers
    if (btnGear) {
        btnGear.onclick = function() {
            inputKey.value = apiKey;
            inputSecret.value = secretKey;
            modal.className = 'modal-overlay active';
        };
    }

    function closeModal() {
        modal.className = 'modal-overlay';
    }

    if (btnClose) btnClose.onclick = closeModal;
    if (btnCancel) btnCancel.onclick = closeModal;

    if (btnSave) {
        btnSave.onclick = function() {
            apiKey = inputKey.value.trim();
            secretKey = inputSecret.value.trim();
            localStorage.setItem('binance_user_apikey', apiKey);
            localStorage.setItem('binance_user_secret', secretKey);
            closeModal();
            syncTime(refresh);
        };
    }

    if (btnClear) {
        btnClear.onclick = function() {
            apiKey = '';
            secretKey = '';
            inputKey.value = '';
            inputSecret.value = '';
            localStorage.removeItem('binance_user_apikey');
            localStorage.removeItem('binance_user_secret');
            closeModal();
            refresh();
        };
    }

    // Set initial tab styling
    if (activeTab === 'spot') {
        tabSpot.className = 'tab-btn active';
        tabFutures.className = 'tab-btn';
    }

    // Initial load
    syncTime(refresh);
    // Auto-refresh every 6 seconds
    setInterval(refresh, 6000);
})();
